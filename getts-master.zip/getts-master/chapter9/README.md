# Getting started

````
npm install
tsc
npm start
````
