function log() {
  console.log('without default export');
}

module.exports = { log };
