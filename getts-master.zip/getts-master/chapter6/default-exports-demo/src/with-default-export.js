function log() {
  console.log('with default export');
}

module.exports.default = { log };
