class Greeter {

    static sayHello(name: string) {

        console.log (`Hello ${name}`);   
    }
}

Greeter.sayHello('John');