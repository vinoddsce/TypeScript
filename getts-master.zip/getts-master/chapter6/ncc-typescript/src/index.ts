import chalk from 'chalk';

const message: string = 'Built with ncc';

console.log(chalk.black.bgGreenBright(message));
