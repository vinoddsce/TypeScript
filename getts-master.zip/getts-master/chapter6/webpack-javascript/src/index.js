const chalk = require('chalk');

const message = 'Bundled by the Webpack';

console.log(chalk.black.bgGreenBright(message));
