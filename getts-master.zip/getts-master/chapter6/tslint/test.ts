const customerName = 'Mary';



const greeting = 'Hello "World"';
