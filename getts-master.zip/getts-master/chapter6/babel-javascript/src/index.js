const chalk = require('chalk');

const message = 'Built with Babel';

console.log(chalk.black.bgGreenBright(message));
