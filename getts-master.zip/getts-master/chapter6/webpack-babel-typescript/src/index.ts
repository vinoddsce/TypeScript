import chalk from 'chalk';

const message: string = 'Built with Babel bundled with Webpack';

console.log(chalk.black.bgGreenBright(message));
