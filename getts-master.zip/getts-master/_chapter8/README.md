# Getting started

````bash
npm install
tsc
node dist/bc101.js
node dist/bc101_proof_of_work.js
````
